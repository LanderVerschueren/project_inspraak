<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" id="carousel-margin">
        <div class="col-md-12">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <?php $count = 0; ?>
                    <?php foreach($projects as $project): ?>
                            <?php if($count == 2) break; ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($count); ?>" class="<?php echo e(($count === 0) ? 'active' : ''); ?>"></li>
                            <?php $count++; ?>
                    <?php endforeach; ?>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <?php $count = 0; ?>
                    <?php foreach($projects as $project): ?>
                            <?php if($count == 2) break; ?>
                            <div class="<?php echo e(($count === 0) ? 'item active' : 'item'); ?>">
                            <img src="<?php echo e(URL::asset('images/'.$project->title.'/'.$project->image_name)); ?>" class=""></li>
                                <div class="carousel-caption">
                                    <h2><?php echo e($project->title); ?></h2>
                                    <p><?php echo e($project->question); ?> - Al <?php echo e($project->likes); ?> personen keurden dit goed!</p>
                                </div>
                            </div>
                            <?php $count++; ?>
                    <?php endforeach; ?>
                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <i class="fa fa-chevron-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <section class="wrapper">
                    <ul class="tabs">
                        <li class="active">Meest recent</li>
                        <li>Meest bekeken</li>
                        <li>Meeste likes</li>
                    </ul>

                    <ul class="tab__content">
                        <li class="active">
                            <div class="content__wrapper">
                                <?php foreach($projects->sortByDesc('date') as $project): ?>                                    
                                    <a href="<?php echo e(url('/project/'.$project->id)); ?>">
                                        <h4> <?php echo e(ucfirst( $project->title )); ?> </h4>
                                        <img src="<?php echo e(URL::asset('images/' . $project->title . '/' . $project->image_name)); ?>" alt="">
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </li>
                        <li>
                            <div class="content__wrapper">
                                <?php foreach($projects->sortByDesc('view_amount') as $project): ?>
                                    <a href="<?php echo e(url('/project/'.$project->id)); ?>">
                                        <h4> <?php echo e(ucfirst( $project->title )); ?> </h4>
                                        <img src="<?php echo e(URL::asset('images/' . $project->title . '/' . $project->image_name)); ?>" alt="">
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </li>
                        <li>
                            <div class="content__wrapper">
                                <?php foreach($projects->sortByDesc('likes') as $project): ?>
                                    <a href="<?php echo e(url('/project/'.$project->id)); ?>">
                                        <h4> <?php echo e(ucfirst( $project->title )); ?> </h4>
                                        <img src="<?php echo e(URL::asset('images/' . $project->title . '/' . $project->image_name)); ?>" alt="">
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </li>
                    </ul>
                </section>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>