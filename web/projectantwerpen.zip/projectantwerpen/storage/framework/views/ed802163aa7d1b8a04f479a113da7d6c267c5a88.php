<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php foreach( $projects as $project ): ?>
				<div class="admin_list">
					<section class="image">
						<img src="<?php echo e(URL::asset('images/' . $project->fotonaam)); ?>" alt="">
					</section>
					<section class="titel">
						<h4><?php echo e($project->titel); ?></h4>
						<h5><?php echo e(ucfirst( $project->categorie )); ?></h5>
					</section>
					<section class="btn_aanpassen">
						<a href="<?php echo e(url('/project/'.$project->id)); ?>" class="btn btn-primary" role="button">Aanpassen</a>
					</section>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>