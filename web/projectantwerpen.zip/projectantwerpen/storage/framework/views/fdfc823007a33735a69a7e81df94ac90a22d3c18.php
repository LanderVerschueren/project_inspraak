<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12 form_general" id="project">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4>Titel project</h4>
					</div>
					<div class="panel-body">
				    	<section>
				    		<img src="<?php echo e(URL::asset('images/meir-2.png')); ?>" alt="">
				    	</section>
				  	</div>
			  	</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>